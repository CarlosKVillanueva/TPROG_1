package examen.clases;

public interface Mostrable {
	void mostrar();
}
