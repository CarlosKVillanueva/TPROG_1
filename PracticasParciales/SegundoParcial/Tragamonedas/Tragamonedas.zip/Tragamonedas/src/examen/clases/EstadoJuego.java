package examen.clases;

public enum EstadoJuego {
	INICIAL, SIN_SUERTE, CAPICUA, GENERALA
}
