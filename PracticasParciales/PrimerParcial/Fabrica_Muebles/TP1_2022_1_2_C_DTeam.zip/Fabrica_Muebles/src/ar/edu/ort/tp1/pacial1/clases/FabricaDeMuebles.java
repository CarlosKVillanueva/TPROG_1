package ar.edu.ort.tp1.pacial1.clases;

import java.util.ArrayList;

public class FabricaDeMuebles implements Mostrable {

	private String nombre;
	private ArrayList<Mueble> muebles;

	
	public FabricaDeMuebles(String nombre) {
		this.nombre = nombre;
		this.muebles = new ArrayList<>();
	}

	public boolean fabricar(Mueble m) {
		boolean retorno = false;
		if (m != null) {
			retorno = muebles.add(m);
			m.mostrar();
		}
		return retorno;
	}

	@Override
	public void mostrar() {
		System.out.printf("Fabrica de Muebles: %s", this.nombre);
		//int contMesas = 0, contSillas = 0, contSillones = 0;
		float acum = 0;
		for (Mueble mueble : muebles) {
			acum += mueble.calcularPrecioVenta();
			/*
				if (mueble instanceof Mesa) {
					contMesas++;
				} else if (mueble instanceof Silla) {
					contSillas++;
				} else {
					contSillones++;
				}
			*/
		}
		System.out.printf("Se han fabricado: %d Mesas, %d Sillas y %d Sillones\nLa venta total fue: $%.2f\n",Mesa.getCONTADOR(), Silla.getCONTADOR(), Sillon.getCONTADOR(), acum);
	}
	
	public Mueble buscarMuebles(String modelo) {
	    int i = 0, cantidadElementos = muebles.size();
	    Mueble elementoBuscado = null;
	
	    while (i < cantidadElementos && elementoBuscado == null) {
	        Mueble elemento = muebles.get(i);
	        if (elemento.modeloCorrecto(modelo)) {
	            elementoBuscado = elemento;
	        } else {
	            i++;
	        }
	    }
	    return elementoBuscado;
	}

	public boolean seHaFabricado(String modelo) {
		return buscarMuebles(modelo) != null;
	}
}
