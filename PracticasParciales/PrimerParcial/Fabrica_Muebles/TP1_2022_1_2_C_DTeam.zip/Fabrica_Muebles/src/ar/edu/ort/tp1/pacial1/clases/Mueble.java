package ar.edu.ort.tp1.pacial1.clases;

public abstract class Mueble implements Mostrable {

	public static final int CIEN = 100;
	//TODO A completar
	private String modelo;
	private float costoBase;
	private float porcentajeGanancia;

	public Mueble(String modelo, float costoBase, float porcentajeGanancia) {
		this.modelo = modelo;
		this.costoBase = costoBase;
		this.porcentajeGanancia = porcentajeGanancia;
	}

	@Override
	public void mostrar() {
		System.out.printf("Fabricando el mueble:\nMueble tipo: %s - Modelo: %s - %.1f\n", getClass().getSimpleName(),this.modelo, calcularPrecioVenta());
	}

	public float calcularPrecioVenta(){
		return calcularPrecioCosto() + (calcularPrecioCosto() * (porcentajeGanancia / CIEN));
	}

	public abstract float calcularPrecioCosto();

	protected float getCostoBase() {
		return costoBase;
	}

	public boolean modeloCorrecto(String modelo) {
	
		return modelo == this.modelo;
	}

}
