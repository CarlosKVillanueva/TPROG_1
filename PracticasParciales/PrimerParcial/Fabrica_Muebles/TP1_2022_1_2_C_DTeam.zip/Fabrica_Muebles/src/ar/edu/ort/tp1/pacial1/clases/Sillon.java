package ar.edu.ort.tp1.pacial1.clases;

public class Sillon extends Mueble {

    private int cantCuerpos;
    private TelaSillon telaSillon;
    private static int CONTADOR;

    public Sillon(String modelo, float costoBase, float porcentajeGanancia, int cantCuerpos, TelaSillon telaSillon) {
        super(modelo, costoBase, porcentajeGanancia);
        this.cantCuerpos = cantCuerpos;
        this.telaSillon = telaSillon;
        ++CONTADOR;
    }

    public static int getCONTADOR() {
        return CONTADOR;
    }

    @Override
    public float calcularPrecioCosto() {
        return super.getCostoBase() * this.cantCuerpos * telaSillon.getPorcentaje();
    }

    //TODO A completar


}
