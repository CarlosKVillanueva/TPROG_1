/**
 * 
 */
package ort.tp1.parcial1.entidades;

/**
 * Representa un producto sin tacc
 */
public class ProductoSinTacc extends Producto {

	private static final String NOMBRE_MOSTRABLE = "Producto Sin TACC";

	//Completar atributos y m�todos


}
