/**
 * 
 */
package ort.tp1.parcial1.entidades;

/**
 * Tipos de pedido posibles
 */
public enum TipoPedido {

	POR_MAYOR, POR_MENOR;
}
