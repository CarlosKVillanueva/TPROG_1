/**
 * 
 */
package ort.tp1.parcial1.entidades;

/**
 * Familias de producto v�lidas
 */
public enum FamiliaProducto {

	LACTEO, PANIFICADO, REPOSTERO, CEREAL
}
